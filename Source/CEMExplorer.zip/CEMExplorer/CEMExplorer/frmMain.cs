using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CEMExplorer.Services;

namespace CEMExplorer
{
    public partial class frmMain : Form
    {
        private readonly SkeletonService skeletonService = new SkeletonService();
        private string? selectedFilePath;
        private bool fileContentsDirty;
        private bool loadingFile;

        public frmMain()
        {
            InitializeComponent();
            UpdateCommandState();
        }

        private void fileSelector_FileNameChanged(object? sender, EventArgs e)
        {
            if (!ConfirmDiscardChanges())
                return;

            LoadRootFolder(fileSelector.FileName.Trim());
        }

        private void LoadRootFolder(string rootFolder)
        {
            tvProject.BeginUpdate();
            try
            {
                tvProject.Nodes.Clear();
                selectedFilePath = null;
                ShowEmptyDetail();

                if (!Directory.Exists(rootFolder))
                {
                    txtTitle.Text = string.Empty;
                    SetStatus(string.IsNullOrWhiteSpace(rootFolder) ? "Select a root folder." : "The selected root folder does not exist.");
                    return;
                }

                DirectoryInfo root = new DirectoryInfo(rootFolder);
                TreeNode rootNode = CreateTreeNode(root);
                tvProject.Nodes.Add(rootNode);
                AddChildren(rootNode, root);
                rootNode.Expand();
                tvProject.SelectedNode = rootNode;

                string title = ReadProjectTitle(rootFolder);
                txtTitle.Text = title;
                SetStatus("Loaded " + root.FullName);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "CEM Explorer", MessageBoxButtons.OK, MessageBoxIcon.Error);
                SetStatus("The root folder could not be loaded.");
            }
            finally
            {
                tvProject.EndUpdate();
                UpdateCommandState();
            }
        }

        private void AddChildren(TreeNode parentNode, DirectoryInfo directory)
        {
            try
            {
                foreach (DirectoryInfo childDirectory in directory.EnumerateDirectories().OrderBy(item => item.Name, StringComparer.OrdinalIgnoreCase))
                {
                    TreeNode childNode = CreateTreeNode(childDirectory);
                    parentNode.Nodes.Add(childNode);
                    AddChildren(childNode, childDirectory);
                }

                foreach (FileInfo file in directory.EnumerateFiles().OrderBy(item => item.Name, StringComparer.OrdinalIgnoreCase))
                    parentNode.Nodes.Add(CreateTreeNode(file));
            }
            catch (UnauthorizedAccessException)
            {
                parentNode.Nodes.Add(new TreeNode("[Access denied]") { ForeColor = System.Drawing.Color.Firebrick });
            }
            catch (IOException ex)
            {
                parentNode.Nodes.Add(new TreeNode("[" + ex.Message + "]") { ForeColor = System.Drawing.Color.Firebrick });
            }
        }

        private static TreeNode CreateTreeNode(FileSystemInfo item)
        {
            return new TreeNode(item.Name)
            {
                Tag = new NodeInfo(item.FullName, item is DirectoryInfo)
            };
        }

        private void tvProject_AfterSelect(object? sender, TreeViewEventArgs e)
        {
            if (e.Node?.Tag is not NodeInfo info)
                return;

            if (!ConfirmDiscardChanges())
                return;

            if (info.IsDirectory)
                ShowFolder(info.FullPath);
            else
                ShowFile(info.FullPath);
        }

        private void ShowFolder(string folderPath)
        {
            selectedFilePath = null;
            fileContentsDirty = false;
            lblDetail.Text = "Folder Contents — " + Path.GetFileName(folderPath);
            txtFileContents.Visible = false;
            lvFolder.Visible = true;
            lvFolder.BringToFront();
            lvFolder.BeginUpdate();
            lvFolder.Items.Clear();

            try
            {
                DirectoryInfo directory = new DirectoryInfo(folderPath);
                foreach (DirectoryInfo childDirectory in directory.EnumerateDirectories().OrderBy(item => item.Name, StringComparer.OrdinalIgnoreCase))
                    lvFolder.Items.Add(CreateListItem(childDirectory));
                foreach (FileInfo file in directory.EnumerateFiles().OrderBy(item => item.Name, StringComparer.OrdinalIgnoreCase))
                    lvFolder.Items.Add(CreateListItem(file));
            }
            catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException)
            {
                SetStatus(ex.Message);
            }
            finally
            {
                lvFolder.EndUpdate();
                UpdateCommandState();
            }
        }

        private static ListViewItem CreateListItem(FileSystemInfo item)
        {
            bool isDirectory = item is DirectoryInfo;
            string size = isDirectory ? string.Empty : FormatFileSize(((FileInfo)item).Length);
            ListViewItem row = new ListViewItem(item.Name);
            row.SubItems.Add(isDirectory ? "Folder" : item.Extension.TrimStart('.').ToUpperInvariant() + " File");
            row.SubItems.Add(size);
            row.SubItems.Add(item.LastWriteTime.ToString("g"));
            row.Tag = new NodeInfo(item.FullName, isDirectory);
            return row;
        }

        private void lvFolder_ItemActivate(object? sender, EventArgs e)
        {
            if (lvFolder.SelectedItems.Count == 0 || lvFolder.SelectedItems[0].Tag is not NodeInfo info)
                return;

            TreeNode? node = FindNode(tvProject.Nodes, info.FullPath);
            if (node != null)
                tvProject.SelectedNode = node;
        }

        private static TreeNode? FindNode(TreeNodeCollection nodes, string fullPath)
        {
            foreach (TreeNode node in nodes)
            {
                if (node.Tag is NodeInfo info && string.Equals(info.FullPath, fullPath, StringComparison.OrdinalIgnoreCase))
                    return node;

                TreeNode? found = FindNode(node.Nodes, fullPath);
                if (found != null)
                    return found;
            }
            return null;
        }

        private void ShowFile(string filePath)
        {
            selectedFilePath = filePath;
            lblDetail.Text = "Selected File — " + Path.GetFileName(filePath);
            lvFolder.Visible = false;
            txtFileContents.Visible = true;
            txtFileContents.BringToFront();

            loadingFile = true;
            try
            {
                if (IsProbablyBinary(filePath))
                {
                    txtFileContents.ReadOnly = true;
                    txtFileContents.Text = "This file appears to be binary and cannot be previewed as text.";
                }
                else
                {
                    txtFileContents.ReadOnly = false;
                    txtFileContents.Text = File.ReadAllText(filePath);
                    txtFileContents.SelectionStart = 0;
                    txtFileContents.SelectionLength = 0;
                }

                fileContentsDirty = false;
                SetStatus(filePath);
            }
            catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException)
            {
                txtFileContents.ReadOnly = true;
                txtFileContents.Text = ex.Message;
                SetStatus("The selected file could not be opened.");
            }
            finally
            {
                loadingFile = false;
                UpdateCommandState();
            }
        }

        private void txtFileContents_TextChanged(object? sender, EventArgs e)
        {
            if (loadingFile || txtFileContents.ReadOnly || selectedFilePath == null)
                return;

            fileContentsDirty = true;
            UpdateCommandState();
        }

        private void btnCreate_Click(object? sender, EventArgs e)
        {
            string baseFolder = fileSelector.FileName.Trim();
            if (!Directory.Exists(baseFolder))
            {
                MessageBox.Show(this, "Select an existing root folder first.", "CEM Explorer", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (!AbbreviationPrompt.TryGet(this, out string abbreviation))
                return;

            string skeletonFile = Path.Combine(AppContext.BaseDirectory, "CEMEXPLORERSKELETON.txt");
            try
            {
                string projectRoot = skeletonService.Create(baseFolder, skeletonFile, abbreviation, txtTitle.Text.Trim());
                fileSelector.FileName = projectRoot;
                SetStatus("Created CEM project structure in " + projectRoot);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "CEM Explorer", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSetup_Click(object? sender, EventArgs e)
        {
            string rootFolder = fileSelector.FileName.Trim();
            string title = txtTitle.Text.Trim();
            if (!Directory.Exists(rootFolder))
            {
                MessageBox.Show(this, "Select an existing root folder first.", "CEM Explorer", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (title.Length == 0)
            {
                MessageBox.Show(this, "Enter a project title first.", "CEM Explorer", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtTitle.Focus();
                return;
            }

            bool isEmpty = !Directory.EnumerateFileSystemEntries(rootFolder).Any();
            if (isEmpty)
            {
                SetStatus("Title is ready. Click Create to generate the project structure.");
                return;
            }

            try
            {
                WriteProjectTitle(rootFolder, title);
                RefreshTreePreservingSelection();
                SetStatus("Project title saved to README.md.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "CEM Explorer", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSave_Click(object? sender, EventArgs e)
        {
            SaveSelectedFile();
        }

        private bool SaveSelectedFile()
        {
            if (selectedFilePath == null || txtFileContents.ReadOnly)
                return true;

            try
            {
                File.WriteAllText(selectedFilePath, txtFileContents.Text, new UTF8Encoding(false));
                fileContentsDirty = false;
                SetStatus("Saved " + selectedFilePath);
                UpdateCommandState();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "CEM Explorer", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        private void btnClose_Click(object? sender, EventArgs e)
        {
            Close();
        }

        private void frmMain_FormClosing(object? sender, FormClosingEventArgs e)
        {
            if (!ConfirmDiscardChanges())
                e.Cancel = true;
        }

        private bool ConfirmDiscardChanges()
        {
            if (!fileContentsDirty)
                return true;

            DialogResult result = MessageBox.Show(this,
                "Save changes to the selected file?",
                "CEM Explorer",
                MessageBoxButtons.YesNoCancel,
                MessageBoxIcon.Question);

            if (result == DialogResult.Cancel)
                return false;
            if (result == DialogResult.Yes)
                return SaveSelectedFile();

            fileContentsDirty = false;
            return true;
        }

        private void RefreshTreePreservingSelection()
        {
            string root = fileSelector.FileName.Trim();
            LoadRootFolder(root);
        }

        private static string ReadProjectTitle(string rootFolder)
        {
            string readme = Path.Combine(rootFolder, "README.md");
            if (!File.Exists(readme))
                return Directory.EnumerateFileSystemEntries(rootFolder).Any()
                    ? new DirectoryInfo(rootFolder).Name
                    : string.Empty;

            foreach (string line in File.ReadLines(readme))
            {
                if (line.StartsWith("# ", StringComparison.Ordinal))
                    return line.Substring(2).Trim();
            }

            return new DirectoryInfo(rootFolder).Name;
        }

        private static void WriteProjectTitle(string rootFolder, string title)
        {
            string readme = Path.Combine(rootFolder, "README.md");
            List<string> lines = File.Exists(readme) ? File.ReadAllLines(readme).ToList() : new List<string>();
            int headingIndex = lines.FindIndex(line => line.StartsWith("# ", StringComparison.Ordinal));
            if (headingIndex >= 0)
                lines[headingIndex] = "# " + title;
            else
                lines.Insert(0, "# " + title);

            File.WriteAllLines(readme, lines, new UTF8Encoding(false));
        }

        private static bool IsProbablyBinary(string filePath)
        {
            byte[] buffer = new byte[4096];
            using FileStream stream = File.OpenRead(filePath);
            int bytesRead = stream.Read(buffer, 0, buffer.Length);
            for (int index = 0; index < bytesRead; index++)
            {
                if (buffer[index] == 0)
                    return true;
            }
            return false;
        }

        private static string FormatFileSize(long bytes)
        {
            if (bytes < 1024)
                return bytes + " B";
            if (bytes < 1024 * 1024)
                return (bytes / 1024d).ToString("0.0") + " KB";
            if (bytes < 1024L * 1024L * 1024L)
                return (bytes / 1024d / 1024d).ToString("0.0") + " MB";
            return (bytes / 1024d / 1024d / 1024d).ToString("0.0") + " GB";
        }

        private void ShowEmptyDetail()
        {
            lblDetail.Text = "Folder Contents";
            lvFolder.Items.Clear();
            lvFolder.Visible = true;
            txtFileContents.Visible = false;
            fileContentsDirty = false;
        }

        private void UpdateCommandState()
        {
            btnCreate.Enabled = Directory.Exists(fileSelector.FileName.Trim());
            btnSetup.Enabled = Directory.Exists(fileSelector.FileName.Trim());
            btnSave.Enabled = selectedFilePath != null && !txtFileContents.ReadOnly && fileContentsDirty;
        }

        private void SetStatus(string text)
        {
            lblStatus.Text = text;
        }

        private sealed class NodeInfo
        {
            public NodeInfo(string fullPath, bool isDirectory)
            {
                FullPath = fullPath;
                IsDirectory = isDirectory;
            }

            public string FullPath { get; }
            public bool IsDirectory { get; }
        }
    }
}
